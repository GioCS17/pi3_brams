Vue.options.delimiters = ['{[{', '}]}'];
var v = new Vue({
    el:'#app2',
    data:{
        step:0.001,
        //Model Configuration Paramteres
        mc_maxgrds: 10,
        mc_nxpmax:10,
        mc_nypmax:10,
        mc_nzpmax:10,
        mc_nzgmax:10,
        mc_maxsclr:10,
        mc_maxsteb:10, //variable of couple model
        mc_maxubtp:10, //variable of couple model

        //Variables for control for latitud and longitud
        ctrl_act_longlat:false,

        // variable support by Grid Model 
        myDate: new Date().toISOString().slice(0,10), 
        maxDate: new Date().toISOString().slice(0,10), 
        minxDate: "2016-01-01", 
        xcells:0,
        ycells:0,
        zcells:0,

        //Model Grids
        mg_expname:"",
        mg_runtype:"",
        mg_timeunit:"",
        mg_timmax:0,
        mg_imonth1:0,
        mg_idate1:0, //day
        mg_iyear1:0,
        mg_time1:0, //hhmm
        mg_ngrids:0,
        mg_nnxp:[],
        mg_nnyp:[],
        mg_nnzp:[],
        mg_nzg:0,
        mg_nzs:0,
        mg_adap:false,
        mg_htran:-1,
        mg_deltax:0,
        mg_deltay:0,
        mg_deltaz:0,
        mg_dzrat:0,
        mg_dtlong:0,
    },
    methods: {
        disableLongLat(){
            console.log(this.ctrl_act_longlat);
            if(!this.ctrl_act_longlat){
                document.getElementById("id_long").readOnly = true;
            }
            else{
                document.getElementById("id_long").readOnly = false;
            }
        },
        addX(value){
            this.mg_nnxp.push(value);
        },
        addY(value){
            this.mg_nnyp.push(value);
        },
        addZ(value){
            this.mg_nnzp.push(value);
        },
        sendRamsin(){
            console.log("entro a method")
            var url='http://127.0.0.1:5000/ramsin';
            axios.post(url,{
                    data:{
                        expname:this.mg_expname,
                    }
            }).then(function(res){
                if(res.status==201)
                    console.log("exitos")

            })
            .catch(function(err){
                console.log(err)
            })
            .then(function(){
                console.log("Finish")
            })

        }
        
    },

});